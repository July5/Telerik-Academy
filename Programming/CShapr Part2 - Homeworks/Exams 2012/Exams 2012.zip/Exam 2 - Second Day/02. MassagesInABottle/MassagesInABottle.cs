﻿using System;

class MassagesInABottle
{
    static void Main()
    {

    }
}

