﻿using System;

class SecretLanguage
{
    static void Main()
    {

    }
}

