﻿using System;

class Cooking
{
    static void Main()
    {

    }
}

