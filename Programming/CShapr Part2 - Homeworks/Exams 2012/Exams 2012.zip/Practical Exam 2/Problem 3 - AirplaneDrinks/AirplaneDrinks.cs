﻿using System;

class AirplaneDrinks
{
    static void Main()
    {

    }
}

