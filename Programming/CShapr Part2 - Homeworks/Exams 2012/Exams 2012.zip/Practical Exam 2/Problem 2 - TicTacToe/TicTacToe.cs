﻿using System;

class TicTacToe
{
    static void Main()
    {

    }
}

