﻿using System;

class ThreeDsimensionalLines
{
    static void Main()
    {

    }
}

